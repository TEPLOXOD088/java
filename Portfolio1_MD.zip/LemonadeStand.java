public class LemonadeStand {
    private static final int LEMON_PRICE = 100; // cents
    private static final int SUGAR_PRICE = 50;
    public static final int CUPS_PER_PITCHER = 8;

    private long cashCents = 10000;
    private long lemons = 0;
    private long sugar = 0;
    private long cupsReady = 0;
    private int priceCents = 100;
    private Recipe recipe = new Recipe(5, 2, 6);

    public long getCashCents() { return cashCents; }
    public long getLemons() { return lemons; }
    public long getSugar() { return sugar; }
    public long getCupsReady() { return cupsReady; }
    public int getPriceCents() { return priceCents; }
    public Recipe getRecipe() { return recipe; }

    public boolean buyIngredients(int lemonCount, int sugarCount) {
        if (lemonCount < 0 || sugarCount < 0) return false;
        long cost = (long) lemonCount * LEMON_PRICE + (long) sugarCount * SUGAR_PRICE;
        if (cost > cashCents) return false;
        cashCents -= cost;
        lemons += lemonCount;
        sugar += sugarCount;
        return true;
    }

    public void setRecipe(Recipe newRecipe) {
        if (newRecipe == null) throw new IllegalArgumentException("Recipe cannot be null.");
        recipe = newRecipe;
    }

    public void setPriceCents(int newPrice) {
        if (newPrice < 1) throw new IllegalArgumentException("Price must be at least one cent.");
        priceCents = newPrice;
    }

    public boolean makePitchers(int count) {
        if (count <= 0) return false;
        long neededLemons = (long) count * recipe.getLemons();
        long neededSugar = (long) count * recipe.getSugar();
        long addedCups = (long) count * CUPS_PER_PITCHER;
        if (neededLemons > lemons || neededSugar > sugar || addedCups > Long.MAX_VALUE - cupsReady) {
            return false;
        }
        lemons -= neededLemons;
        sugar -= neededSugar;
        cupsReady += addedCups;
        return true;
    }

    public int sellToCustomers(int customers) {
        if (customers < 1 || customers > 500) {
            throw new IllegalArgumentException("Customers must be between 1 and 500.");
        }
        int sold = (int) Math.min(cupsReady, customers);
        cupsReady -= sold;
        cashCents += (long) sold * priceCents;
        return sold;
    }

    public long discardLeftovers() {
        long wasted = cupsReady;
        cupsReady = 0;
        return wasted;
    }
}
