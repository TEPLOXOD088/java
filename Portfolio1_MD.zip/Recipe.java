public class Recipe {
    private final int lemons;
    private final int sugar;
    private final int water;

    public Recipe(int lemons, int sugar, int water) {
        if (lemons < 0 || sugar < 0 || water < 0 || lemons + sugar + water == 0) {
            throw new IllegalArgumentException("Recipe needs at least one ingredient and no negative amounts.");
        }
        this.lemons = lemons;
        this.sugar = sugar;
        this.water = water;
    }

    public int getLemons() { return lemons; }
    public int getSugar() { return sugar; }
    public int getWater() { return water; }
}
