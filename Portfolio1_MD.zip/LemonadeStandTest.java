import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LemonadeStandTest {
    @Test
    void startsWithOneHundredDollars() {
        assertEquals(10000, new LemonadeStand().getCashCents());
    }

    @Test
    void buysIngredientsAndDeductsCash() {
        LemonadeStand stand = new LemonadeStand();
        assertTrue(stand.buyIngredients(10, 4));
        assertEquals(8800, stand.getCashCents());
        assertEquals(10, stand.getLemons());
        assertEquals(4, stand.getSugar());
    }

    @Test
    void cannotSpendMoreThanAvailable() {
        LemonadeStand stand = new LemonadeStand();
        assertFalse(stand.buyIngredients(101, 0));
        assertEquals(10000, stand.getCashCents());
        assertEquals(0, stand.getLemons());
    }

    @Test
    void makesAndSellsLemonade() {
        LemonadeStand stand = new LemonadeStand();
        stand.buyIngredients(10, 4);
        assertTrue(stand.makePitchers(2));
        assertEquals(16, stand.getCupsReady());
        assertEquals(0, stand.getLemons());
        assertEquals(5, stand.sellToCustomers(5));
        assertEquals(9300, stand.getCashCents());
        assertEquals(11, stand.discardLeftovers());
        assertEquals(0, stand.getCupsReady());
    }

    @Test
    void recipeCanBeChangedAndIngredientsCarryOver() {
        LemonadeStand stand = new LemonadeStand();
        stand.buyIngredients(6, 4);
        stand.setRecipe(new Recipe(2, 1, 5));
        assertTrue(stand.makePitchers(2));
        stand.discardLeftovers();
        assertEquals(2, stand.getLemons());
        assertEquals(2, stand.getSugar());
    }

    @Test
    void rejectsInvalidPricesAndAmounts() {
        LemonadeStand stand = new LemonadeStand();
        assertThrows(IllegalArgumentException.class, () -> stand.setPriceCents(0));
        assertFalse(stand.buyIngredients(-1, 0));
        assertFalse(stand.makePitchers(-1));
        assertThrows(IllegalArgumentException.class, () -> new Recipe(0, 0, 0));
    }
}
