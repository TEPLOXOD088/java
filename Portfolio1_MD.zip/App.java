import java.util.Random;
import java.util.Scanner;

public class App {
    private static final Scanner INPUT = new Scanner(System.in);
    private static final Random RANDOM = new Random();

    public static void main(String[] args) {
        LemonadeStand stand = new LemonadeStand();
        int day = 1;
        System.out.println("Welcome to My Lemonade Stand!");

        while (true) {
            System.out.println("\nDay " + day + ": Preparation Phase");
            boolean preparing = true;
            while (preparing) {
                printMenu(stand);
                int choice = readInt("What would you like to do? ", 0, 5);
                switch (choice) {
                    case 0:
                        System.out.println("Thanks for playing!");
                        return;
                    case 1:
                        int lemons = readInt("How many lemons ($1 each)? ", 0, Integer.MAX_VALUE);
                        int sugar = readInt("How many cups of sugar ($0.50 each)? ", 0, Integer.MAX_VALUE);
                        if (stand.buyIngredients(lemons, sugar)) System.out.println("Purchase complete!");
                        else System.out.println("Not enough cash for that purchase.");
                        break;
                    case 2:
                        int recipeLemons = readInt("Lemons per pitcher: ", 0, Integer.MAX_VALUE);
                        int recipeSugar = readInt("Sugar cups per pitcher: ", 0, Integer.MAX_VALUE);
                        int recipeWater = readInt("Water cups per pitcher: ", 0, Integer.MAX_VALUE);
                        try {
                            stand.setRecipe(new Recipe(recipeLemons, recipeSugar, recipeWater));
                            System.out.println("Recipe updated!");
                        } catch (IllegalArgumentException error) {
                            System.out.println(error.getMessage());
                        }
                        break;
                    case 3:
                        int price = readMoney("Price per cup ($, at least $0.01): ");
                        stand.setPriceCents(price);
                        System.out.println("Price updated!");
                        break;
                    case 4:
                        int pitchers = readInt("How many pitchers? ", 1, Integer.MAX_VALUE);
                        if (stand.makePitchers(pitchers)) System.out.println("Made " + pitchers + " pitchers!");
                        else System.out.println("Not enough ingredients for that many pitchers.");
                        break;
                    case 5:
                        preparing = false;
                        break;
                    default:
                        break;
                }
            }

            int customers = RANDOM.nextInt(500) + 1;
            int sold = stand.sellToCustomers(customers);
            long leftover = stand.discardLeftovers();
            System.out.println("\nDay " + day + ": Selling Phase");
            System.out.println(customers + " customers visited today.");
            System.out.println("Sold " + sold + " cups for " + money((long) sold * stand.getPriceCents()) + ".");
            System.out.println("Unsold cups thrown away: " + leftover);
            System.out.println("Cash remaining: " + money(stand.getCashCents()));
            System.out.println("Let's try again tomorrow!");
            day++;
        }
    }

    private static void printMenu(LemonadeStand stand) {
        System.out.println("\n----------------------------");
        System.out.println("Lemons: " + stand.getLemons());
        System.out.println("Sugar (cups): " + stand.getSugar());
        System.out.println("Water: Unlimited (free)");
        System.out.println("Pitchers ready: " + (stand.getCupsReady() / 8));
        System.out.println("Cash: " + money(stand.getCashCents()));
        System.out.println("Price per cup: " + money(stand.getPriceCents()));
        System.out.println("1. Purchase Ingredients");
        System.out.println("2. Tweak the Recipe");
        System.out.println("3. Set the Price");
        System.out.println("4. Make Pitchers of Lemonade");
        System.out.println("5. Move Onto the Selling Phase");
        System.out.println("0. Quit");
    }

    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String answer = INPUT.nextLine().trim();
            try {
                int number = Integer.parseInt(answer);
                if (number >= min && number <= max) return number;
            } catch (NumberFormatException ignored) { }
            System.out.println("Enter a whole number between " + min + " and " + max + ".");
        }
    }

    private static int readMoney(String prompt) {
        while (true) {
            System.out.print(prompt);
            String answer = INPUT.nextLine().trim().replaceFirst("^\\$", "");
            try {
                java.math.BigDecimal amount = new java.math.BigDecimal(answer);
                int cents = amount.movePointRight(2).intValueExact();
                if (cents >= 1) return cents;
            } catch (NumberFormatException | ArithmeticException ignored) { }
            System.out.println("Enter a price in dollars with no more than two decimal places (example: 1.25).");
        }
    }

    private static String money(long cents) {
        return String.format("$%d.%02d", cents / 100, cents % 100);
    }
}
